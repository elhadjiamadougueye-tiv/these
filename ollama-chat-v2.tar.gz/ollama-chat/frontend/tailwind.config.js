/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter var', 'Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      colors: {
        surface: {
          0: '#0f0f10',
          1: '#161618',
          2: '#1c1c1f',
          3: '#242428',
          4: '#2e2e33',
        },
        accent: {
          DEFAULT: '#7c6af7',
          hover: '#6b5ae6',
          light: '#a394fa',
        },
        border: '#2e2e3a',
      },
    },
  },
  plugins: [],
}
