import { useState, useEffect, useRef, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  Send, Square, Share2, FileText, X, ChevronDown,
  Paperclip, Settings2, Check
} from 'lucide-react'
import { fetchChat, shareChat, streamMessage, fetchDocuments } from '../api/client'
import { MessageBubble } from '../components/MessageBubble'
import Sidebar from '../components/Sidebar'

export default function ChatPage() {
  const { chatId } = useParams()
  const navigate = useNavigate()
  const [chat, setChat] = useState(null)
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [streaming, setStreaming] = useState(false)
  const [streamingContent, setStreamingContent] = useState('')
  const [documents, setDocuments] = useState([])
  const [ragDocIds, setRagDocIds] = useState([])
  const [showRag, setShowRag] = useState(false)
  const [shareInfo, setShareInfo] = useState(null)
  const [sidebarRefresh, setSidebarRefresh] = useState(0)
  const [showShareToast, setShowShareToast] = useState(false)
  const bottomRef = useRef(null)
  const textareaRef = useRef(null)
  const abortRef = useRef(null)

  useEffect(() => {
    if (chatId) loadChat()
    else { setChat(null); setMessages([]) }
  }, [chatId])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, streamingContent])

  useEffect(() => {
    fetchDocuments().then(setDocuments).catch(() => {})
  }, [])

  const loadChat = async () => {
    try {
      const data = await fetchChat(chatId)
      setChat(data)
      setMessages(data.messages)
      setShareInfo({ is_shared: data.is_shared, share_token: data.share_token })
    } catch { navigate('/chat') }
  }

  const handleSend = async () => {
    if (!input.trim() || streaming || !chatId) return

    const userContent = input.trim()
    setInput('')
    setStreaming(true)
    setStreamingContent('')

    const userMsg = { id: Date.now(), role: 'user', content: userContent, created_at: new Date() }
    setMessages(prev => [...prev, userMsg])

    try {
      const res = await streamMessage(chatId, userContent, ragDocIds.length > 0, ragDocIds)
      const reader = res.body.getReader()
      const decoder = new TextDecoder()
      abortRef.current = reader

      let buffer = ''
      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop()

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue
          try {
            const json = JSON.parse(line.slice(6))
            if (json.token) {
              setStreamingContent(prev => prev + json.token)
            }
            if (json.done) {
              setSidebarRefresh(n => n + 1)
            }
            if (json.error) {
              console.error('Stream error:', json.error)
            }
          } catch {}
        }
      }

      // Flush final content
      setMessages(prev => {
        const last = [...prev]
        setStreamingContent(sc => {
          if (sc) {
            last.push({ id: Date.now() + 1, role: 'assistant', content: sc, created_at: new Date() })
          }
          return ''
        })
        return last
      })
      // Reload to get persisted messages
      await loadChat()
    } catch (err) {
      console.error(err)
    } finally {
      setStreaming(false)
      setStreamingContent('')
      abortRef.current = null
      textareaRef.current?.focus()
    }
  }

  const handleStop = () => {
    abortRef.current?.cancel()
    setStreaming(false)
  }

  const handleShare = async () => {
    if (!chatId) return
    const data = await shareChat(chatId)
    setShareInfo(data)
    if (data.is_shared) {
      const url = `${window.location.origin}/shared/${data.share_token}`
      navigator.clipboard.writeText(url)
      setShowShareToast(true)
      setTimeout(() => setShowShareToast(false), 3000)
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const allMessages = [
    ...messages,
    ...(streamingContent ? [{ id: 'streaming', role: 'assistant', content: streamingContent }] : []),
  ]

  return (
    <div className="flex h-screen bg-surface-0 overflow-hidden">
      <Sidebar onNewChat={() => {}} refreshTrigger={sidebarRefresh} />

      <main className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        {chat && (
          <header className="h-12 flex items-center justify-between px-4 border-b border-border bg-surface-1 flex-shrink-0">
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-xs font-medium text-gray-300 truncate">{chat.title}</span>
              <span className="text-[10px] px-1.5 py-0.5 bg-surface-3 rounded text-gray-500 flex-shrink-0">
                {chat.model}
              </span>
            </div>

            <div className="flex items-center gap-1">
              {/* Share toast */}
              {showShareToast && (
                <span className="flex items-center gap-1 text-xs text-green-400 mr-2">
                  <Check className="w-3 h-3" /> Lien copié !
                </span>
              )}
              <button
                onClick={handleShare}
                className={`btn-ghost text-xs flex items-center gap-1 ${shareInfo?.is_shared ? 'text-accent' : ''}`}
                title={shareInfo?.is_shared ? 'Désactiver le partage' : 'Partager'}
              >
                <Share2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </header>
        )}

        {/* Messages area */}
        <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6">
          {!chatId && (
            <div className="flex flex-col items-center justify-center h-full text-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-accent/10 border border-accent/20
                              flex items-center justify-center">
                <svg className="w-8 h-8 text-accent" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path strokeLinecap="round" strokeLinejoin="round"
                    d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09Z" />
                </svg>
              </div>
              <div>
                <h2 className="text-xl font-semibold text-gray-200">Ollama Chat</h2>
                <p className="text-sm text-gray-500 mt-1">Choisissez un modèle et démarrez un nouveau chat</p>
              </div>
            </div>
          )}

          {allMessages.map((msg, i) => (
            <MessageBubble
              key={msg.id || i}
              message={msg}
              isStreaming={msg.id === 'streaming'}
            />
          ))}

          {streaming && !streamingContent && (
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-lg bg-surface-3 border border-border flex items-center justify-center">
                <span className="text-xs text-gray-400">AI</span>
              </div>
              <div className="bg-surface-2 border border-border rounded-2xl px-4 py-3">
                <div className="flex gap-1">
                  {[0, 1, 2].map(i => (
                    <div key={i} className="w-1.5 h-1.5 rounded-full bg-gray-500"
                      style={{ animation: `blink 1.2s ${i * 0.4}s infinite` }} />
                  ))}
                </div>
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Input area */}
        {chatId && (
          <div className="flex-shrink-0 border-t border-border bg-surface-1 p-3">
            {/* RAG selector */}
            {showRag && documents.length > 0 && (
              <div className="mb-2 p-2 bg-surface-2 border border-border rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-gray-400">Documents RAG</span>
                  <button onClick={() => setShowRag(false)} className="text-gray-600 hover:text-gray-400">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="space-y-1 max-h-32 overflow-y-auto">
                  {documents.map(doc => (
                    <label key={doc.id}
                      className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-surface-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={ragDocIds.includes(doc.id)}
                        onChange={(e) => setRagDocIds(prev =>
                          e.target.checked ? [...prev, doc.id] : prev.filter(id => id !== doc.id)
                        )}
                        className="accent-accent"
                      />
                      <FileText className="w-3 h-3 text-gray-500 flex-shrink-0" />
                      <span className="text-xs text-gray-300 truncate">{doc.filename}</span>
                      <span className="text-[10px] text-gray-600 ml-auto">{doc.chunk_count} chunks</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            <div className="flex items-end gap-2">
              {/* RAG toggle */}
              <button
                onClick={() => setShowRag(p => !p)}
                title="Activer le RAG"
                className={`p-2 rounded-lg transition-all flex-shrink-0 ${
                  ragDocIds.length > 0
                    ? 'bg-accent/20 text-accent border border-accent/30'
                    : 'hover:bg-surface-3 text-gray-500'
                }`}
              >
                <FileText className="w-4 h-4" />
              </button>

              {/* Textarea */}
              <div className="flex-1 relative">
                <textarea
                  ref={textareaRef}
                  value={input}
                  onChange={(e) => {
                    setInput(e.target.value)
                    e.target.style.height = 'auto'
                    e.target.style.height = Math.min(e.target.scrollHeight, 200) + 'px'
                  }}
                  onKeyDown={handleKeyDown}
                  placeholder="Message… (Shift+Entrée pour sauter une ligne)"
                  rows={1}
                  className="input-base w-full resize-none min-h-[40px] max-h-[200px] pr-10
                             py-2.5 leading-relaxed"
                  style={{ height: 'auto' }}
                />
              </div>

              {/* Send / Stop */}
              {streaming ? (
                <button
                  onClick={handleStop}
                  className="p-2 bg-red-500/20 hover:bg-red-500/30 text-red-400
                             border border-red-500/30 rounded-lg transition-all flex-shrink-0"
                >
                  <Square className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={handleSend}
                  disabled={!input.trim()}
                  className="btn-primary p-2 flex-shrink-0"
                >
                  <Send className="w-4 h-4" />
                </button>
              )}
            </div>

            {ragDocIds.length > 0 && (
              <p className="text-[10px] text-accent/70 mt-1.5 ml-9">
                {ragDocIds.length} document(s) sélectionné(s) pour le RAG
              </p>
            )}
          </div>
        )}
      </main>
    </div>
  )
}
