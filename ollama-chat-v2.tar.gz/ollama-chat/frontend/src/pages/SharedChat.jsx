import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { API } from '../api/client'
import { MessageBubble } from '../components/MessageBubble'

export default function SharedChat() {
  const { token } = useParams()
  const [chat, setChat] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    fetch(`${API}/chats/shared/${token}`)
      .then(r => { if (!r.ok) throw new Error('Introuvable'); return r.json() })
      .then(setChat)
      .catch(() => setError('Cette conversation n\'existe pas ou n\'est plus partagée.'))
  }, [token])

  if (error) return (
    <div className="min-h-screen bg-surface-0 flex items-center justify-center text-gray-400">
      {error}
    </div>
  )

  if (!chat) return (
    <div className="min-h-screen bg-surface-0 flex items-center justify-center">
      <svg className="w-8 h-8 text-accent animate-spin" viewBox="0 0 24 24" fill="none">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
      </svg>
    </div>
  )

  return (
    <div className="min-h-screen bg-surface-0">
      <header className="sticky top-0 bg-surface-1/80 backdrop-blur border-b border-border px-6 py-3">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-sm font-semibold text-gray-200">{chat.title}</h1>
            <p className="text-xs text-gray-500">{chat.model} · Conversation partagée</p>
          </div>
          <span className="text-xs px-2 py-1 bg-accent/10 text-accent border border-accent/20 rounded-full">
            Lecture seule
          </span>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-4 py-8 space-y-6">
        {chat.messages.map((msg, i) => (
          <MessageBubble key={i} message={msg} />
        ))}
      </div>
    </div>
  )
}
