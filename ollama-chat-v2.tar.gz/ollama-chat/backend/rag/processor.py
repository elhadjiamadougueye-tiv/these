import os
import uuid
import hashlib
from pathlib import Path
from typing import List, Tuple
import chromadb
from chromadb.config import Settings as ChromaSettings
from sentence_transformers import SentenceTransformer
import pypdf
import docx
from config import get_settings

settings = get_settings()

# Chargement du modèle d'embedding (léger, multilingue)
_embed_model = None


def get_embed_model():
    global _embed_model
    if _embed_model is None:
        _embed_model = SentenceTransformer("paraphrase-multilingual-MiniLM-L12-v2")
    return _embed_model


def get_chroma_client():
    return chromadb.HttpClient(
        host=settings.chroma_host,
        port=settings.chroma_port,
        settings=ChromaSettings(anonymized_telemetry=False),
    )


# ---------- Extraction de texte ----------

def extract_text_from_pdf(path: str) -> str:
    reader = pypdf.PdfReader(path)
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def extract_text_from_docx(path: str) -> str:
    doc = docx.Document(path)
    return "\n".join(p.text for p in doc.paragraphs if p.text.strip())


def extract_text_from_txt(path: str) -> str:
    import chardet
    with open(path, "rb") as f:
        raw = f.read()
    enc = chardet.detect(raw)["encoding"] or "utf-8"
    return raw.decode(enc, errors="replace")


def extract_text(path: str, file_type: str) -> str:
    ext = file_type.lower()
    if ext == "pdf":
        return extract_text_from_pdf(path)
    elif ext in ("docx", "doc"):
        return extract_text_from_docx(path)
    elif ext in ("txt", "md", "csv", "py", "js", "ts", "json"):
        return extract_text_from_txt(path)
    else:
        return extract_text_from_txt(path)


# ---------- Chunking ----------

def chunk_text(text: str, chunk_size: int = 800, overlap: int = 100) -> List[str]:
    words = text.split()
    chunks = []
    i = 0
    while i < len(words):
        chunk = " ".join(words[i: i + chunk_size])
        if chunk.strip():
            chunks.append(chunk)
        i += chunk_size - overlap
    return chunks


# ---------- Indexation ----------

async def index_document(
    file_path: str,
    file_type: str,
    user_id: int,
    doc_id: int,
) -> Tuple[str, int]:
    """Index a document in ChromaDB. Returns (collection_name, chunk_count)."""
    text = extract_text(file_path, file_type)
    chunks = chunk_text(text)

    if not chunks:
        return "", 0

    collection_name = f"user_{user_id}_doc_{doc_id}"
    model = get_embed_model()
    embeddings = model.encode(chunks, show_progress_bar=False).tolist()

    client = get_chroma_client()
    collection = client.get_or_create_collection(
        name=collection_name,
        metadata={"hnsw:space": "cosine"},
    )

    ids = [f"chunk_{i}" for i in range(len(chunks))]
    collection.add(documents=chunks, embeddings=embeddings, ids=ids)

    return collection_name, len(chunks)


async def query_document(
    collection_name: str,
    question: str,
    n_results: int = 4,
) -> List[str]:
    """Query the vector store and return relevant chunks."""
    model = get_embed_model()
    q_embed = model.encode([question]).tolist()

    client = get_chroma_client()
    try:
        collection = client.get_collection(collection_name)
        results = collection.query(query_embeddings=q_embed, n_results=n_results)
        return results["documents"][0] if results["documents"] else []
    except Exception:
        return []


async def delete_document_collection(collection_name: str):
    try:
        client = get_chroma_client()
        client.delete_collection(collection_name)
    except Exception:
        pass


async def query_user_documents(
    user_id: int,
    collection_names: List[str],
    question: str,
    n_results: int = 3,
) -> str:
    """Query multiple collections and return context string."""
    if not collection_names:
        return ""

    all_chunks = []
    for col in collection_names:
        chunks = await query_document(col, question, n_results)
        all_chunks.extend(chunks)

    if not all_chunks:
        return ""

    context = "\n\n---\n\n".join(all_chunks[:6])
    return f"Contexte extrait des documents :\n\n{context}\n\n"
