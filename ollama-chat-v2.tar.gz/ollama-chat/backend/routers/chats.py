import json
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import Optional, List
from database import get_db
import models, auth
from ollama_client import get_ollama_stream_client
from rag.processor import query_user_documents

router = APIRouter(prefix="/chats", tags=["chats"])


class CreateChatRequest(BaseModel):
    model: str
    title: Optional[str] = None
    system_prompt: Optional[str] = None


class SendMessageRequest(BaseModel):
    content: str
    use_rag: bool = False
    rag_document_ids: Optional[List[int]] = None


class UpdateChatRequest(BaseModel):
    title: Optional[str] = None
    system_prompt: Optional[str] = None


async def get_user_chat(chat_id: int, user_id: int, db: AsyncSession) -> models.Chat:
    result = await db.execute(
        select(models.Chat).where(
            models.Chat.id == chat_id,
            models.Chat.user_id == user_id,
        )
    )
    chat = result.scalar_one_or_none()
    if not chat:
        raise HTTPException(404, "Conversation introuvable")
    return chat


@router.get("")
async def list_chats(
    db: AsyncSession = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    result = await db.execute(
        select(models.Chat)
        .where(models.Chat.user_id == user.id)
        .order_by(models.Chat.updated_at.desc())
    )
    chats = result.scalars().all()
    return [
        {
            "id": c.id,
            "title": c.title,
            "model": c.model,
            "is_shared": c.is_shared,
            "share_token": c.share_token,
            "created_at": c.created_at,
            "updated_at": c.updated_at,
            "message_count": len(c.messages),
        }
        for c in chats
    ]


@router.post("", status_code=201)
async def create_chat(
    payload: CreateChatRequest,
    db: AsyncSession = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    chat = models.Chat(
        user_id=user.id,
        model=payload.model,
        title=payload.title or "Nouvelle conversation",
        system_prompt=payload.system_prompt,
    )
    db.add(chat)
    await db.commit()
    await db.refresh(chat)
    return {"id": chat.id, "title": chat.title, "model": chat.model}


@router.get("/{chat_id}")
async def get_chat(
    chat_id: int,
    db: AsyncSession = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    chat = await get_user_chat(chat_id, user.id, db)
    return {
        "id": chat.id,
        "title": chat.title,
        "model": chat.model,
        "system_prompt": chat.system_prompt,
        "is_shared": chat.is_shared,
        "share_token": chat.share_token,
        "messages": [
            {"id": m.id, "role": m.role, "content": m.content, "created_at": m.created_at}
            for m in chat.messages
        ],
    }


@router.put("/{chat_id}")
async def update_chat(
    chat_id: int,
    payload: UpdateChatRequest,
    db: AsyncSession = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    chat = await get_user_chat(chat_id, user.id, db)
    if payload.title:
        chat.title = payload.title
    if payload.system_prompt is not None:
        chat.system_prompt = payload.system_prompt
    await db.commit()
    return {"message": "ok"}


@router.delete("/{chat_id}")
async def delete_chat(
    chat_id: int,
    db: AsyncSession = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    chat = await get_user_chat(chat_id, user.id, db)
    await db.delete(chat)
    await db.commit()
    return {"message": "Conversation supprimée"}


@router.post("/{chat_id}/share")
async def toggle_share(
    chat_id: int,
    db: AsyncSession = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    chat = await get_user_chat(chat_id, user.id, db)
    if chat.is_shared:
        chat.is_shared = False
        chat.share_token = None
    else:
        chat.generate_share_token()
    await db.commit()
    return {"is_shared": chat.is_shared, "share_token": chat.share_token}


@router.get("/shared/{token}")
async def get_shared_chat(token: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(models.Chat).where(
            models.Chat.share_token == token,
            models.Chat.is_shared == True,
        )
    )
    chat = result.scalar_one_or_none()
    if not chat:
        raise HTTPException(404, "Conversation introuvable ou non partagée")
    return {
        "id": chat.id,
        "title": chat.title,
        "model": chat.model,
        "messages": [
            {"role": m.role, "content": m.content, "created_at": m.created_at}
            for m in chat.messages
        ],
    }


@router.post("/{chat_id}/messages/stream")
async def stream_message(
    chat_id: int,
    payload: SendMessageRequest,
    db: AsyncSession = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    chat = await get_user_chat(chat_id, user.id, db)

    # Message utilisateur → DB
    user_msg = models.Message(chat_id=chat.id, role="user", content=payload.content)
    db.add(user_msg)

    # Historique des messages pour Ollama
    history = [{"role": m.role, "content": m.content} for m in chat.messages]

    # RAG : enrichissement du prompt si documents sélectionnés
    user_content = payload.content
    if payload.use_rag and payload.rag_document_ids:
        result = await db.execute(
            select(models.Document).where(
                models.Document.id.in_(payload.rag_document_ids),
                models.Document.user_id == user.id,
            )
        )
        docs = result.scalars().all()
        collections = [d.collection_name for d in docs if d.collection_name]
        if collections:
            context = await query_user_documents(user.id, collections, payload.content)
            if context:
                user_content = context + "\nQuestion : " + payload.content

    # Construction des messages pour /api/chat
    messages = []
    if chat.system_prompt:
        messages.append({"role": "system", "content": chat.system_prompt})
    messages.extend(history)
    messages.append({"role": "user", "content": user_content})

    await db.commit()
    auto_title = len(chat.messages) == 1

    async def generate():
        full_response = ""
        try:
            # Utilise le client avec auth Bearer + timeouts 1800s (comme votre config Nginx)
            async with get_ollama_stream_client() as client:
                async with client.stream(
                    "POST",
                    "/api/chat",
                    json={"model": chat.model, "messages": messages, "stream": True},
                ) as response:
                    if response.status_code == 401:
                        yield f"data: {json.dumps({'error': 'Clé API Ollama invalide (401)'})}\n\n"
                        return

                    async for line in response.aiter_lines():
                        if not line:
                            continue
                        try:
                            data = json.loads(line)
                            token = data.get("message", {}).get("content", "")
                            if token:
                                full_response += token
                                yield f"data: {json.dumps({'token': token})}\n\n"
                            if data.get("done"):
                                break
                        except json.JSONDecodeError:
                            continue

            # Persistance de la réponse complète
            assistant_msg = models.Message(
                chat_id=chat.id,
                role="assistant",
                content=full_response,
                model=chat.model,
            )
            db.add(assistant_msg)

            if auto_title and full_response:
                words = payload.content.split()
                chat.title = " ".join(words[:8]) + ("..." if len(words) > 8 else "")

            await db.commit()
            yield f"data: {json.dumps({'done': True, 'title': chat.title})}\n\n"

        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
